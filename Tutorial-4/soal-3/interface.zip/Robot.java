class Robot implements CanTalk, CanWalk {
    public void walk(){
        System.out.println("Robot is walking");
    }
    public void talk(){
        System.out.println("Robot is talking");
    }
}