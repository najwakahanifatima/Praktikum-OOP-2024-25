class Human implements CanTalk, CanWalk {
    public void walk(){
        System.out.println("Human is walking");
    }
    public void talk(){
        System.out.println("Human is talking");
    }
}